package com.example.money


import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern
import android.webkit.WebView
import android.widget.ImageView
import android.widget.ProgressBar
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter

class MainActivity : AppCompatActivity() {
    lateinit var ProgressBar : ProgressBar
    private lateinit var transactionAdapter: TransactionAdapter
    private val transactions = mutableListOf<Transaction>()
    private var totalSpent = 0.0
    private var currentBalance = 0.0
    private lateinit var monthly_limmit : TextView
    private lateinit var settingsButton : Button
    private lateinit var monthlyLimitTextView: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        transactionAdapter = TransactionAdapter(transactions)
        monthly_limmit = findViewById(R.id.monthlyLimitTextView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = transactionAdapter



        settingsButton = findViewById(R.id.settingsButton)

        // Set click listener for the settings button

        val refreshButton: Button = findViewById(R.id.refreshButton)
        refreshButton.setOnClickListener {
            refreshTransactions()
            monthlyLimitTextView = findViewById(R.id.monthlyLimitTextView)


            val sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE)
            val monthlyLimit = sharedPreferences.getString("monthlyLimit", "₹0.00")


            monthlyLimitTextView.text = "Monthly Limit: ₹$monthlyLimit"
            ProgressBar = findViewById(R.id.progressBar)
            val monthlyLimitValue = monthlyLimit?.toFloat()  // Convert to Float to handle decimal values
            val progressPercentage = ((totalSpent / monthlyLimitValue!!) * 100).toInt()
            ProgressBar.progress = progressPercentage.coerceAtMost(100)


        }

        val showGraphButton: Button = findViewById(R.id.showGraphButton)
        showGraphButton.setOnClickListener {
            // Show the graph in a dialog when the button is clicked
            showGraphPopup()

        }



        settingsButton.setOnClickListener {
            // Start the SettingsActivity when the button is clicked
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun updateProgressBar(monthlyLimit: Double) {


    }


private fun showGraphPopup() {
    // Create a dialog to show the graph
    val dialogView = layoutInflater.inflate(R.layout.graph_popup, null)
    val graphDialog = android.app.AlertDialog.Builder(this)
        .setView(dialogView)
        .setCancelable(true)
        .create()

    val lineChart: LineChart = dialogView.findViewById(R.id.lineChart)
    val selectDateButton: Button = dialogView.findViewById(R.id.selectDateButton)

    // Prepare the data for the graph: Only include "Spent" transactions
    val dateSpentMap = mutableMapOf<String, Double>()
    transactions.filter { it.type == "Spent" }.forEach {
        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(it.date)
        dateSpentMap[dateKey] = dateSpentMap.getOrDefault(dateKey, 0.0) + it.amount
    }

    // Setup graph with data
    val entries = dateSpentMap.entries.sortedBy { it.key }.mapIndexed { index, entry ->
        Entry(index.toFloat(), entry.value.toFloat())
    }

    val dataSet = LineDataSet(entries, "Date vs Spending")
    dataSet.color = ContextCompat.getColor(this, R.color.purpleLight)
    dataSet.valueTextColor = ContextCompat.getColor(this, R.color.black)
    dataSet.setDrawFilled(true)
    dataSet.fillColor = ContextCompat.getColor(this, R.color.purpleLight)
    dataSet.lineWidth = 2f
    dataSet.setDrawCircles(true)
    dataSet.setCircleColor(ContextCompat.getColor(this, R.color.white))
    dataSet.setCircleRadius(5f)
    dataSet.mode = LineDataSet.Mode.CUBIC_BEZIER

    val lineData = LineData(dataSet)
    lineChart.data = lineData
    lineChart.invalidate()

    val xAxis = lineChart.xAxis
    val dateKeys = dateSpentMap.keys.toList()
    xAxis.valueFormatter = IndexAxisValueFormatter(dateKeys)
    xAxis.position = XAxis.XAxisPosition.BOTTOM
    xAxis.setGranularity(1f)
    xAxis.setLabelCount(dateKeys.size, true)
    xAxis.textSize = 12f
    xAxis.setLabelRotationAngle(45f)

    // Date picker for selecting a specific date
    selectDateButton.setOnClickListener {
        val calendar = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            calendar.set(year, month, dayOfMonth)
            val selectedDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)

            // Filter the transactions by selected date
            val filteredEntries = dateSpentMap.filter { it.key == selectedDate }
            val filteredLineEntries = filteredEntries.map { entry ->
                Entry(filteredEntries.keys.indexOf(entry.key).toFloat(), entry.value.toFloat())
            }

            // Update the graph with the filtered data for that date
            val filteredDataSet = LineDataSet(filteredLineEntries, "Spent on $selectedDate")
            filteredDataSet.color = ContextCompat.getColor(this, R.color.purpleLight)
            filteredDataSet.valueTextColor = ContextCompat.getColor(this, R.color.black)
            filteredDataSet.setDrawFilled(true)
            filteredDataSet.fillColor = ContextCompat.getColor(this, R.color.purpleLight)
            filteredDataSet.lineWidth = 2f
            filteredDataSet.setDrawCircles(true)
            filteredDataSet.setCircleColor(ContextCompat.getColor(this, R.color.white))
            filteredDataSet.setCircleRadius(5f)
            filteredDataSet.mode = LineDataSet.Mode.CUBIC_BEZIER

            val filteredLineData = LineData(filteredDataSet)
            lineChart.data = filteredLineData
            lineChart.invalidate()
        }

        val datePicker = DatePickerDialog(
            this,
            dateSetListener,
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.show()
    }

    // Close button to dismiss the graph dialog
    val closeGraphButton: Button = dialogView.findViewById(R.id.closeGraphButton)
    closeGraphButton.setOnClickListener {
        graphDialog.dismiss()
    }

    graphDialog.show()
}



    private fun checkSMSPermissionAndFetchData() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_SMS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fetchSMSData()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_SMS),
                SMS_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun fetchSMSData() {
        CoroutineScope(Dispatchers.Main).launch {
            withContext(Dispatchers.IO) { parseSMSData() }
            updateUI()
        }
    }

    private fun parseSMSData() {
        val uri: Uri = Uri.parse("content://sms/inbox")
        val projection = arrayOf("body", "date")
        val dateFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val currentMonth = dateFormat.format(Date()) // Current month, e.g., "2024-11"

        val cursor: Cursor? = contentResolver.query(uri, projection, null, null, "date DESC")
        cursor?.use {
            val bodyIndex = it.getColumnIndex("body")
            val dateIndex = it.getColumnIndex("date")

            transactions.clear() // Clear the existing transactions before refreshing

            while (it.moveToNext()) {
                val body = it.getString(bodyIndex)
                val dateInMillis = it.getLong(dateIndex)
                val messageDate = Date(dateInMillis)
                val messageMonth = dateFormat.format(messageDate)

                if (messageMonth == currentMonth) {
                    val transaction = extractTransaction(body, messageDate)
                    if (transaction != null) {
                        transactions.add(transaction)
                        if (transaction.type == "Spent") {
                            totalSpent += transaction.amount
                        }
                        if (currentBalance == 0.0) {
                            currentBalance = extractBalance(body)
                        }
                    }
                }
            }
        }
    }

    private fun extractTransaction(smsBody: String, date: Date): Transaction? {
        val spendPattern = Pattern.compile("(?i)Rs\\.\\s?(\\d+(\\.\\d{1,2})?)\\s+transferred\\s+from\\s+A/c")
        val depositPattern = Pattern.compile("(?i)Rs\\.\\s?(\\d+(\\.\\d{1,2})?)\\s+deposited\\s+in\\s+cash")
        val creditedPattern = Pattern.compile("(?i)Rs\\.\\s?(\\d+(\\.\\d{1,2})?)\\s+Credited")

        return when {
            spendPattern.matcher(smsBody).find() -> {
                val matcher = spendPattern.matcher(smsBody)
                matcher.find()
                Transaction(
                    amount = matcher.group(1)?.toDoubleOrNull() ?: 0.0,
                    date = date,
                    type = "Spent",
                    details = smsBody
                )
            }

            depositPattern.matcher(smsBody).find() -> {
                val matcher = depositPattern.matcher(smsBody)
                matcher.find()
                Transaction(
                    amount = matcher.group(1)?.toDoubleOrNull() ?: 0.0,
                    date = date,
                    type = "Deposited",
                    details = smsBody
                )
            }

            creditedPattern.matcher(smsBody).find() -> {
                val matcher = creditedPattern.matcher(smsBody)
                matcher.find()
                Transaction(
                    amount = matcher.group(1)?.toDoubleOrNull() ?: 0.0,
                    date = date,
                    type = "Credited",
                    details = smsBody
                )
            }

            else -> null
        }
    }

    private fun extractBalance(smsBody: String): Double {
        val balancePattern = Pattern.compile("(?i)Total Bal:Rs\\.?\\s?(\\d+(\\.\\d{1,2})?)")
        val matcher = balancePattern.matcher(smsBody)

        return if (matcher.find()) {
            matcher.group(1)?.toDoubleOrNull() ?: 0.0
        } else {
            0.0
        }
    }

    private fun updateUI() {
        findViewById<TextView>(R.id.totalSpentTextView).text = "Total Spent: ₹%.2f".format(totalSpent)
        findViewById<TextView>(R.id.currentBalanceTextView).text = "Current Balance: ₹%.2f".format(currentBalance)
        transactionAdapter.notifyDataSetChanged()
    }

    private fun refreshTransactions() {
        totalSpent = 0.0
        currentBalance = 0.0
        checkSMSPermissionAndFetchData()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchSMSData()
            } else {
                Toast.makeText(
                    this,
                    "Permission Denied! Cannot fetch SMS data.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    companion object {
        private const val SMS_PERMISSION_REQUEST_CODE = 101
    }
}
