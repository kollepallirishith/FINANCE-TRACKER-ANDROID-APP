package com.example.money;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.money.R;

public class SettingsActivity extends AppCompatActivity {

    private EditText monthlyLimitEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize UI components
        monthlyLimitEditText = findViewById(R.id.monthlylimittext);
        saveButton = findViewById(R.id.save);

        // Load saved settings
        loadSettings();

        // Save button click listener
        saveButton.setOnClickListener(v -> saveSettings());
    }

    private void loadSettings() {
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);

        // Load saved monthly limit
        String monthlyLimit = sharedPreferences.getString("monthlyLimit", "₹0.00");
        monthlyLimitEditText.setText(monthlyLimit);
    }

    private void saveSettings() {
        // Get the monthly limit entered by the user
        String monthlyLimit = monthlyLimitEditText.getText().toString();

        // Save the monthly limit to SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("monthlyLimit", monthlyLimit);
        editor.apply();

        // Optionally, show a message or update UI to reflect changes
        // e.g., Toast.makeText(this, "Settings Saved!", Toast.LENGTH_SHORT).show();
    }
}
