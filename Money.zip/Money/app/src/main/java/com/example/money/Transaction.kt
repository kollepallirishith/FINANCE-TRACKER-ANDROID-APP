package com.example.money

import java.util.Date

data class Transaction(
    val amount: Double,
    val date: Date,
    val type: String,
    val details: String
)
