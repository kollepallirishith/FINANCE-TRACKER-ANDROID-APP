//import android.content.SharedPreferences
//import android.os.Bundle
//import android.widget.Button
//import android.widget.EditText
//import androidx.appcompat.app.AppCompatActivity
//import com.example.money.R
//
//class SettingsActivity : AppCompatActivity() {
//
//    private lateinit var monthlyLimitEditText: EditText
//    private lateinit var saveButton: Button
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_settings)
//
//        // Initialize UI components
//        monthlyLimitEditText = findViewById(R.id.monthlylimittext)
//        saveButton = findViewById(R.id.save)
//
//        // Load saved settings
//        loadSettings()
//
//        // Save button click listener
//        saveButton.setOnClickListener {
//            saveSettings()
//        }
//    }
//
//    private fun loadSettings() {
//        val sharedPreferences: SharedPreferences = getSharedPreferences("settings", MODE_PRIVATE)
//
//        // Load saved monthly limit
//        val monthlyLimit = sharedPreferences.getString("monthlyLimit", "₹0.00")
//        monthlyLimitEditText.setText(monthlyLimit)
//    }
//
//    private fun saveSettings() {
//        // Get the monthly limit entered by the user
//        val monthlyLimit = monthlyLimitEditText.text.toString()
//
//        // Save the monthly limit to SharedPreferences
//        val sharedPreferences: SharedPreferences = getSharedPreferences("settings", MODE_PRIVATE)
//        val editor = sharedPreferences.edit()
//        editor.putString("monthlyLimit", monthlyLimit)
//        editor.apply()
//
//        // Optionally, show a message or update UI to reflect changes
//        // e.g., Toast.makeText(this, "Settings Saved!", Toast.LENGTH_SHORT).show()
//    }
//}
